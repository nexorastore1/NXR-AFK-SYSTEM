Config = {}

-- ============ DETEKSI AFK ============
-- Berapa lama player diam sebelum UI verifikasi muncul (dalam detik)
Config.IdleTime = 3          -- 3600 detik = 1 jam

-- Interval pengecekan posisi (ms)
Config.CheckInterval = 1000

-- Jarak minimal (meter) agar dianggap "bergerak"
Config.MoveThreshold = 1.0

-- Perubahan sudut kamera minimal (derajat) agar dianggap "aktif"
Config.CamThreshold = 2.0

-- ============ KODE VERIFIKASI ============
Config.CodeLength = 6           -- panjang kode
Config.CodeTime = 60            -- detik untuk mengisi kode
Config.Charset = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789' -- tanpa I,O,0,1 biar tidak ambigu

-- ============ AFK ZONE ============
-- Lokasi player dibuang kalau gagal verifikasi
Config.AfkZone = {
    x = -75.0,
    y = -819.0,
    z = 326.1745,
    heading = 340.0,
    radius = 60.0               -- radius zona (untuk pengecekan server)
}

-- Tombol untuk membuka verifikasi keluar dari AFK Zone
Config.ExitKey = 38             -- 38 = E
Config.ExitKeyLabel = 'E'

-- ============ PEMBATASAN DI AFK ZONE ============
Config.Restrictions = {
    godMode = true,             -- tidak bisa dipukul / ditembak
    freezeHealth = true,        -- health & armor dikunci penuh
    freezeStatus = true,        -- lapar & haus tidak berkurang
    blockSalary = true,         -- gaji / paycheck diblokir
    blockCombat = true,         -- tidak bisa menyerang
    blockWeapons = true,        -- senjata dilucuti selama di zona
    blockVehicle = true,        -- tidak bisa masuk kendaraan
    blockInventory = true,      -- tidak bisa buka inventory / makan / minum
    blockDrop = true            -- tidak bisa buang item
}

-- Daftar event yang diblokir dari sisi server saat player AFK.
-- Sesuaikan dengan framework kamu.
Config.BlockedServerEvents = {
    -- ESX
    'esx:useItem',
    'esx_basicneeds:eat',
    'esx_basicneeds:drink',
    'esx:removeInventoryItem',
    -- QBCore
    'QBCore:Server:UseItem',
    'qb-inventory:server:useItem',
}

-- Framework: 'esx', 'qb', atau 'standalone'
Config.Framework = 'standalone'

-- ============ NOTIFIKASI ============
Config.Locale = {
    warning      = 'Aktivitas tidak terdeteksi. Masukkan kode verifikasi.',
    wrongCode    = 'Kode salah. Kode baru dibuat.',
    verified     = 'Verifikasi berhasil.',
    movedToAfk   = 'Kamu dipindahkan ke AFK Zone.',
    backToNormal = 'Kamu dikembalikan ke posisi sebelumnya.',
    blocked      = 'Aksi ini dinonaktifkan selama kamu berada di AFK Zone.',
    pressToExit  = 'Tekan [%s] untuk keluar dari AFK Zone'
}
