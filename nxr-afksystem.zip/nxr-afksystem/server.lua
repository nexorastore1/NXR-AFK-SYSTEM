-- state[src] = { code, mode, expiresAt, afk, returnCoords }
local state = {}

math.randomseed(os.time())

-- =====================================================
-- UTIL
-- =====================================================

local function generateCode()
    local charset = Config.Charset
    local code = ''
    for _ = 1, Config.CodeLength do
        local i = math.random(1, #charset)
        code = code .. charset:sub(i, i)
    end
    return code
end

local function getState(src)
    if not state[src] then
        state[src] = { afk = false }
    end
    return state[src]
end

local function clearChallenge(src)
    local s = getState(src)
    s.code = nil
    s.mode = nil
    s.expiresAt = nil
end

-- =====================================================
-- REQUEST KODE
-- =====================================================

RegisterNetEvent('nxr-afk:requestCode', function(mode)
    local src = source
    local s = getState(src)

    if mode ~= 'verify' and mode ~= 'exit' then return end
    if mode == 'exit' and not s.afk then return end
    if mode == 'verify' and s.afk then return end

    -- cegah spam request
    if s.expiresAt and os.time() < s.expiresAt then return end

    s.code = generateCode()
    s.mode = mode
    s.expiresAt = os.time() + Config.CodeTime

    TriggerClientEvent('nxr-afk:showCode', src, s.code, Config.CodeTime, mode)

    -- timer otoritatif di server
    local myExpire = s.expiresAt
    SetTimeout(Config.CodeTime * 1000 + 500, function()
        local cur = state[src]
        if not cur then return end
        if cur.expiresAt ~= myExpire then return end -- sudah selesai / diganti

        clearChallenge(src)

        if mode == 'verify' then
            TriggerClientEvent('nxr-afk:sendToAfk', src)
        else
            -- gagal keluar dari AFK Zone, UI ditutup saja
            TriggerClientEvent('nxr-afk:sendToAfk', src)
        end
    end)
end)

-- =====================================================
-- SUBMIT KODE
-- =====================================================

RegisterNetEvent('nxr-afk:submitCode', function(input)
    local src = source
    local s = getState(src)

    if type(input) ~= 'string' then return end
    if not s.code or not s.expiresAt then return end
    if os.time() > s.expiresAt then return end

    if input:upper() == s.code then
        local mode = s.mode
        clearChallenge(src)
        TriggerClientEvent('nxr-afk:accepted', src, mode)
    else
        -- salah: kosongkan input, ganti kode, waktu tetap berjalan
        s.code = generateCode()
        TriggerClientEvent('nxr-afk:wrongCode', src, s.code)
    end
end)

-- =====================================================
-- STATE AFK
-- =====================================================

RegisterNetEvent('nxr-afk:setAfkState', function(afk, returnCoords)
    local src = source
    local s = getState(src)
    s.afk = afk and true or false
    if afk then
        s.returnCoords = returnCoords
    else
        s.returnCoords = nil
    end
end)

AddEventHandler('playerDropped', function()
    state[source] = nil
end)

-- =====================================================
-- BLOKIR AKSI SAAT AFK
-- =====================================================

-- Blokir event framework yang menguntungkan player
for _, eventName in ipairs(Config.BlockedServerEvents) do
    AddEventHandler(eventName, function()
        local src = source
        local s = state[src]
        if s and s.afk then
            CancelEvent()
            TriggerClientEvent('nxr-afk:blocked', src)
        end
    end)
end

-- =====================================================
-- BLOKIR GAJI / PAYCHECK
-- =====================================================

--[[
    Cara pakai di script gaji kamu:

    if exports['nxr-afk']:IsPlayerAfk(source) then
        return -- gaji tidak dibayarkan
    end
]]

exports('IsPlayerAfk', function(src)
    local s = state[src]
    return s ~= nil and s.afk == true
end)

exports('GetAfkPlayers', function()
    local list = {}
    for src, s in pairs(state) do
        if s.afk then list[#list + 1] = src end
    end
    return list
end)

-- Paksa player masuk/keluar AFK Zone dari script lain
exports('ForceAfk', function(src)
    TriggerClientEvent('nxr-afk:sendToAfk', src)
end)

-- Auto-patch ESX: blokir addMoney/addAccountMoney selama AFK
if Config.Framework == 'esx' and Config.Restrictions.blockSalary then
    CreateThread(function()
        Wait(2000)
        local ESX = exports['es_extended'] and exports['es_extended']:getSharedObject()
        if not ESX then return end

        local originalGet = ESX.GetPlayerFromId
        ESX.GetPlayerFromId = function(src)
            local xPlayer = originalGet(src)
            if not xPlayer then return xPlayer end

            local s = state[src]
            if s and s.afk then
                local blockedAdd = function() return false end
                xPlayer.addMoney = blockedAdd
                xPlayer.addAccountMoney = blockedAdd
                xPlayer.addInventoryItem = blockedAdd
            end
            return xPlayer
        end
    end)
end

-- =====================================================
-- COMMAND ADMIN
-- =====================================================

RegisterCommand('afkcheck', function(source, args)
    if source ~= 0 then return end -- console only
    local target = tonumber(args[1])
    if not target then
        print('^3[nxr-afk]^7 Pakai: afkcheck [id]')
        return
    end
    local s = state[target]
    print(('^2[nxr-afk]^7 Player %d AFK: %s'):format(target, tostring(s and s.afk or false)))
end, true)

RegisterCommand('afkforce', function(source, args)
    if source ~= 0 then return end
    local target = tonumber(args[1])
    if not target then
        print('^3[nxr-afk]^7 Pakai: afkforce [id]')
        return
    end
    TriggerClientEvent('nxr-afk:sendToAfk', target)
end, true)
