fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'nxr-afksystem'
author 'NEXORA'
description 'Sistem deteksi AFK dengan verifikasi kode dan AFK Zone'
version '1.0.1'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

ui_page 'index.html'

files {
    'index.html',
    'style.css',
    'script.js'
}
