local lastCoords   = nil
local lastCamRot   = nil
local idleSeconds  = 0
local verifying    = false      -- UI verifikasi sedang terbuka
local isAfk        = false      -- player sedang di AFK Zone
local returnCoords = nil        -- posisi sebelum dibuang ke AFK Zone

-- =====================================================
-- UTIL
-- =====================================================

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName('~b~[NXR-AFK]~s~ ' .. msg)
    EndTextCommandThefeedPostTicker(false, true)
end

local function resetIdle()
    idleSeconds = 0
end

local function openUI(mode, code, seconds)
    verifying = true
    SetNuiFocus(true, true)
    SendNUIMessage({
        action  = 'open',
        mode    = mode,          -- 'verify' | 'exit'
        code    = code,
        seconds = seconds,
        length  = Config.CodeLength
    })
end

local function closeUI()
    verifying = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

-- =====================================================
-- DETEKSI IDLE
-- =====================================================

CreateThread(function()
    while true do
        Wait(Config.CheckInterval)

        local ped = PlayerPedId()

        if isAfk or verifying or IsPauseMenuActive() then
            lastCoords = GetEntityCoords(ped)
            lastCamRot = GetGameplayCamRot(2)
            goto continue
        end

        local coords = GetEntityCoords(ped)
        local camRot = GetGameplayCamRot(2)

        if lastCoords == nil then
            lastCoords = coords
            lastCamRot = camRot
            goto continue
        end

        local moved = #(coords - lastCoords) > Config.MoveThreshold
        local looked = math.abs(camRot.z - lastCamRot.z) > Config.CamThreshold
                    or math.abs(camRot.x - lastCamRot.x) > Config.CamThreshold

        if moved or looked then
            resetIdle()
        else
            idleSeconds = idleSeconds + (Config.CheckInterval / 1000)
        end

        lastCoords = coords
        lastCamRot = camRot

        if idleSeconds >= Config.IdleTime then
            resetIdle()
            TriggerServerEvent('nxr-afk:requestCode', 'verify')
        end

        ::continue::
    end
end)

-- =====================================================
-- EVENT DARI SERVER
-- =====================================================

-- Server mengirim kode baru + sisa waktu
RegisterNetEvent('nxr-afk:showCode', function(code, seconds, mode)
    openUI(mode, code, seconds)
    notify(Config.Locale.warning)
end)

-- Kode salah: input dikosongkan, kode diganti
RegisterNetEvent('nxr-afk:wrongCode', function(newCode)
    SendNUIMessage({ action = 'wrong', code = newCode })
end)

-- Kode benar
RegisterNetEvent('nxr-afk:accepted', function(mode)
    closeUI()
    resetIdle()

    if mode == 'exit' then
        releaseFromAfk()
    else
        notify(Config.Locale.verified)
    end
end)

-- Gagal verifikasi dalam 1 menit -> masuk AFK Zone
RegisterNetEvent('nxr-afk:sendToAfk', function()
    closeUI()
    sendToAfkZone()
end)

-- Server menolak aksi karena player AFK
RegisterNetEvent('nxr-afk:blocked', function()
    notify(Config.Locale.blocked)
end)

-- =====================================================
-- MASUK / KELUAR AFK ZONE
-- =====================================================

function sendToAfkZone()
    local ped = PlayerPedId()

    -- simpan posisi asal (jangan ditimpa kalau sudah di AFK Zone)
    if not isAfk then
        local c = GetEntityCoords(ped)
        returnCoords = {
            x = c.x,
            y = c.y,
            z = c.z,
            heading = GetEntityHeading(ped)
        }
    end
    TriggerServerEvent('nxr-afk:setAfkState', true, returnCoords)

    -- keluarkan dari kendaraan
    if IsPedInAnyVehicle(ped, false) then
        TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 16)
        Wait(500)
        ped = PlayerPedId()
    end

    if Config.Restrictions.blockWeapons then
        RemoveAllPedWeapons(ped, true)
    end

    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do Wait(10) end

    local z = Config.AfkZone
    SetEntityCoordsNoOffset(ped, z.x, z.y, z.z, false, false, false)
    SetEntityHeading(ped, z.heading)

    -- pastikan collision ter-load
    RequestCollisionAtCoord(z.x, z.y, z.z)
    local timeout = GetGameTimer() + 5000
    while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < timeout do
        Wait(10)
    end

    isAfk = true

    DoScreenFadeIn(700)
    notify(Config.Locale.movedToAfk)
end

function releaseFromAfk()
    isAfk = false

    local ped = PlayerPedId()
    local back = returnCoords

    DoScreenFadeOut(500)
    while not IsScreenFadedOut() do Wait(10) end

    if back then
        SetEntityCoordsNoOffset(ped, back.x, back.y, back.z, false, false, false)
        SetEntityHeading(ped, back.heading or 0.0)
        RequestCollisionAtCoord(back.x, back.y, back.z)
        local timeout = GetGameTimer() + 5000
        while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < timeout do
            Wait(10)
        end
    end

    -- lepas semua proteksi
    SetEntityInvincible(ped, false)
    SetPlayerInvincible(PlayerId(), false)
    SetEntityProofs(ped, false, false, false, false, false, false, false, false)
    SetPlayerCanDoDriveBy(PlayerId(), true)
    FreezeEntityPosition(ped, false)

    returnCoords = nil
    resetIdle()
    TriggerServerEvent('nxr-afk:setAfkState', false)

    DoScreenFadeIn(700)
    notify(Config.Locale.backToNormal)
end

-- =====================================================
-- LOOP PEMBATASAN DI AFK ZONE
-- =====================================================

CreateThread(function()
    while true do
        if isAfk then
            local ped = PlayerPedId()
            local plr = PlayerId()
            local r   = Config.Restrictions

            if r.godMode then
                SetEntityInvincible(ped, true)
                SetPlayerInvincible(plr, true)
                SetEntityProofs(ped, true, true, true, true, true, true, true, true)
                SetPedCanRagdoll(ped, false)
                ClearPedBloodDamage(ped)
            end

            if r.freezeHealth then
                SetEntityHealth(ped, GetEntityMaxHealth(ped))
                SetPedArmour(ped, 100)
                SetPlayerHealthRechargeMultiplier(plr, 0.0)
            end

            if r.blockCombat then
                SetPlayerCanDoDriveBy(plr, false)
                DisablePlayerFiring(plr, true)
                DisableControlAction(0, 24, true)   -- attack
                DisableControlAction(0, 25, true)   -- aim
                DisableControlAction(0, 140, true)  -- melee ringan
                DisableControlAction(0, 141, true)
                DisableControlAction(0, 142, true)
                DisableControlAction(0, 257, true)
                DisableControlAction(0, 263, true)
                DisableControlAction(0, 264, true)
            end

            if r.blockWeapons then
                SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)
                DisableControlAction(0, 37, true)   -- weapon wheel
                DisableControlAction(0, 157, true)  -- slot 1-9
                DisableControlAction(0, 158, true)
                DisableControlAction(0, 159, true)
                DisableControlAction(0, 160, true)
                DisableControlAction(0, 161, true)
                DisableControlAction(0, 162, true)
                DisableControlAction(0, 163, true)
                DisableControlAction(0, 164, true)
                DisableControlAction(0, 165, true)
            end

            if r.blockVehicle then
                DisableControlAction(0, 23, true)   -- masuk kendaraan
                DisableControlAction(0, 75, true)   -- keluar kendaraan
                if IsPedInAnyVehicle(ped, false) then
                    local veh = GetVehiclePedIsIn(ped, false)
                    TaskLeaveVehicle(ped, veh, 16)
                end
            end

            if r.blockInventory then
                DisableControlAction(0, 289, true)  -- F2 inventory
                DisableControlAction(0, 170, true)  -- F3
                DisableControlAction(0, 166, true)  -- F5
                DisableControlAction(0, 167, true)  -- F6
                DisableControlAction(0, 168, true)  -- F7
                DisableControlAction(0, 311, true)  -- K
                DisableControlAction(0, 244, true)  -- M
                DisableControlAction(0, 20, true)   -- Z
            end

            -- kunci status lapar/haus tiap detik (dikirim juga ke server)
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- Kunci status lapar & haus (ESX / QBCore)
CreateThread(function()
    while true do
        Wait(5000)
        if isAfk and Config.Restrictions.freezeStatus then
            if Config.Framework == 'esx' then
                TriggerEvent('esx_status:set', 'hunger', 1000000)
                TriggerEvent('esx_status:set', 'thirst', 1000000)
            elseif Config.Framework == 'qb' then
                TriggerServerEvent('hud:server:RelieveStress', 100)
                TriggerServerEvent('consumables:server:setStatus', 'hunger', 100)
                TriggerServerEvent('consumables:server:setStatus', 'thirst', 100)
            end
        end
    end
end)

-- Prompt "Tekan E untuk keluar"
CreateThread(function()
    while true do
        if isAfk and not verifying then
            SetTextFont(4)
            SetTextScale(0.42, 0.42)
            SetTextColour(255, 255, 255, 220)
            SetTextCentre(true)
            SetTextOutline()
            BeginTextCommandDisplayText('STRING')
            AddTextComponentSubstringPlayerName(
                string.format(Config.Locale.pressToExit, Config.ExitKeyLabel)
            )
            EndTextCommandDisplayText(0.5, 0.90)

            if IsControlJustPressed(0, Config.ExitKey) then
                TriggerServerEvent('nxr-afk:requestCode', 'exit')
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- =====================================================
-- NUI CALLBACK
-- =====================================================

RegisterNUICallback('submit', function(data, cb)
    TriggerServerEvent('nxr-afk:submitCode', data.code)
    cb({ ok = true })
end)

RegisterNUICallback('timeout', function(_, cb)
    -- server tetap yang memutuskan, ini hanya sinkronisasi tampilan
    closeUI()
    cb({ ok = true })
end)

-- =====================================================
-- EXPORT
-- =====================================================

exports('IsAfk', function()
    return isAfk
end)

exports('GetIdleTime', function()
    return idleSeconds
end)

-- Reset saat resource restart / player spawn
AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() and verifying then
        SetNuiFocus(false, false)
    end
end)
