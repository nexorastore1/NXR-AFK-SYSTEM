const root     = document.getElementById('root');
const codeEl   = document.getElementById('code');
const inputRow = document.getElementById('inputRow');
const meter    = document.getElementById('meterFill');
const timeLeft = document.getElementById('timeLeft');
const headline = document.getElementById('headline');
const sub      = document.getElementById('sub');
const hint     = document.getElementById('hint');

let total = 60;
let left = 60;
let ticker = null;
let length = 6;

/* ---------- util ---------- */

function post(name, data) {
    return fetch(`https://${GetParentResourceName()}/${name}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=UTF-8' },
        body: JSON.stringify(data || {})
    }).catch(() => {});
}

function renderCode(code, shuffle) {
    codeEl.innerHTML = '';
    for (const ch of code) {
        const s = document.createElement('span');
        s.textContent = ch;
        codeEl.appendChild(s);
    }
    if (shuffle) {
        codeEl.classList.remove('shuffle');
        void codeEl.offsetWidth;
        codeEl.classList.add('shuffle');
    }
}

function buildInputs(n) {
    inputRow.innerHTML = '';
    for (let i = 0; i < n; i++) {
        const box = document.createElement('input');
        box.maxLength = 1;
        box.autocomplete = 'off';
        box.spellcheck = false;
        box.dataset.index = i;
        inputRow.appendChild(box);
    }
    wireInputs();
}

function boxes() {
    return Array.from(inputRow.querySelectorAll('input'));
}

function value() {
    return boxes().map(b => b.value).join('').toUpperCase();
}

function clearInputs(focus) {
    boxes().forEach(b => (b.value = ''));
    if (focus !== false) boxes()[0].focus();
}

function wireInputs() {
    boxes().forEach((box, i) => {
        box.addEventListener('input', () => {
            box.value = box.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
            inputRow.classList.remove('error');
            hint.className = 'hint';
            hint.textContent = 'Salah ketik akan mengganti kode.';

            if (box.value && i < length - 1) boxes()[i + 1].focus();
            if (value().length === length) submit();
        });

        box.addEventListener('keydown', e => {
            if (e.key === 'Backspace' && !box.value && i > 0) {
                boxes()[i - 1].focus();
            }
            if (e.key === 'Enter' && value().length === length) submit();
        });

        box.addEventListener('paste', e => {
            e.preventDefault();
            const text = (e.clipboardData.getData('text') || '')
                .toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, length);
            boxes().forEach((b, j) => (b.value = text[j] || ''));
            if (value().length === length) submit();
        });
    });
}

function submit() {
    post('submit', { code: value() });
}

/* ---------- countdown ---------- */

function startTimer(seconds) {
    total = seconds;
    left = seconds;
    meter.style.width = '100%';
    meter.classList.remove('urgent');
    timeLeft.textContent = left;

    clearInterval(ticker);
    ticker = setInterval(() => {
        left--;
        timeLeft.textContent = Math.max(left, 0);
        meter.style.width = Math.max((left / total) * 100, 0) + '%';
        if (left <= 10) meter.classList.add('urgent');
        if (left <= 0) {
            clearInterval(ticker);
            post('timeout');
        }
    }, 1000);
}

/* ---------- pesan dari client ---------- */

window.addEventListener('message', ev => {
    const d = ev.data;

    if (d.action === 'open') {
        length = d.length || 6;

        if (d.mode === 'exit') {
            headline.textContent = 'Keluar dari AFK Zone';
            sub.textContent = 'Masukkan kode untuk kembali ke posisi terakhirmu.';
        } else {
            headline.textContent = 'Kamu masih di sana?';
            sub.textContent = 'Salin kode di bawah untuk melanjutkan permainan.';
        }

        hint.className = 'hint';
        hint.textContent = 'Salah ketik akan mengganti kode.';
        inputRow.classList.remove('error', 'ok');

        renderCode(d.code, false);
        buildInputs(length);
        startTimer(d.seconds || 60);

        root.classList.remove('hidden');
        setTimeout(() => boxes()[0].focus(), 50);
    }

    if (d.action === 'wrong') {
        inputRow.classList.add('error');
        hint.className = 'hint fault';
        hint.textContent = 'Kode salah. Kode baru sudah dibuat.';
        renderCode(d.code, true);
        clearInputs(true);
    }

    if (d.action === 'close') {
        clearInterval(ticker);
        root.classList.add('hidden');
        clearInputs(false);
    }
});
